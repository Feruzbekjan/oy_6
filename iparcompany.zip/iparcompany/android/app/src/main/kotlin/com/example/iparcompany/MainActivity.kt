package com.example.iparcompany

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
