import 'package:flutter/material.dart';

class AppColor {
  final green  = const Color(0xFF199A8E); 
  final white = const Color(0xFFFFFFFF);
  final textColor = const Color(0xFF101623);
  final grey = const Color(0xFFA1A8B0);
  final greyish = const Color(0xFF717784);
final textFieldBackground = const Color(0xFFF9FAFB);
final textfieldBorder = const Color(0xFFE5E7EB);

}