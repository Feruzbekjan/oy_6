class AppImages {
  final logo = "assets/images/splash/iparlogo.png";
  final rasm1 = "assets/images/onboarding/rasm.png";
  final rasm2 = "assets/images/onboarding/rasm2.png";
  final rasm3 = "assets/images/onboarding/rasm3.png";
}
