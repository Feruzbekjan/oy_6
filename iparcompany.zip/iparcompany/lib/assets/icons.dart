class AppIcons {
  final nextPage = "assets/icons/onboarding/next_page.svg";
  final arrowLeft = 'assets/icons/global/arrow_left.svg';
  final eye = 'assets/icons/login/eye.svg';
  final parol = 'assets/icons/login/parol.svg';
  final sms = 'assets/icons/login/sms.svg';
  final google = 'assets/icons/login/google.svg';
  final notification = 'assets/icons/home/notification.svg';
}
