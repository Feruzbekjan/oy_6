class AppRouteNames {
  final splash = '/';
  final onBoarding = '/onboarding';
  final welcome = '/welcome';
  final login = '/login';
  final singUp = "/signUp";
  final home = "/home";
}
