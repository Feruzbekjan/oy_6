enum AuthStatus{ 
  pure, unAuth, authen, admin
}